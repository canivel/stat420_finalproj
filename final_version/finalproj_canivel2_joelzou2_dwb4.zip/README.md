# stat420_finalproj

Stat 420 - Summer 2019 - Final Proj

## requirements

    - install.packages(lubridate)
    - install.packages(ggplot2)
    - install.packages(cluster)
    - install.packages(tidyverse)
    - install.packages(caret)
    - install.packages(magrittr)
    - install.packages(Matrix)
    - install.packages(faraway)
    - install.packages(shiny)
    - install.packages(jsonlite)
    - install.packages(xgboost)
